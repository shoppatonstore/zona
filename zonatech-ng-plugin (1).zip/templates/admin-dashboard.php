<?php
/**
 * Frontend Admin Dashboard Template
 * Allows admins to view analytics without accessing WordPress admin
 */

if (!defined('ABSPATH')) exit;

// Check if user is admin
if (!current_user_can('manage_options')) {
    wp_redirect(site_url('/zonatech-dashboard/'));
    exit;
}

global $wpdb;

// Handle form submissions
$message = '';
$message_type = '';

// Handle single question addition
if (isset($_POST['add_single_question']) && wp_verify_nonce($_POST['question_nonce'], 'zonatech_add_question')) {
    $exam_type = sanitize_text_field($_POST['exam_type']);
    $subject = sanitize_text_field($_POST['subject']);
    $year = intval($_POST['year']);
    $question_text = sanitize_textarea_field($_POST['question_text']);
    $option_a = sanitize_text_field($_POST['option_a']);
    $option_b = sanitize_text_field($_POST['option_b']);
    $option_c = sanitize_text_field($_POST['option_c']);
    $option_d = sanitize_text_field($_POST['option_d']);
    $correct_answer = sanitize_text_field($_POST['correct_answer']);
    $explanation = sanitize_textarea_field($_POST['explanation']);
    
    $table_questions = $wpdb->prefix . 'zonatech_questions';
    
    $result = $wpdb->insert($table_questions, array(
        'exam_type' => $exam_type,
        'subject' => $subject,
        'year' => $year,
        'question_text' => $question_text,
        'option_a' => $option_a,
        'option_b' => $option_b,
        'option_c' => $option_c,
        'option_d' => $option_d,
        'correct_answer' => $correct_answer,
        'explanation' => $explanation,
        'created_at' => current_time('mysql')
    ));
    
    if ($result) {
        $message = 'Question added successfully!';
        $message_type = 'success';
    } else {
        $message = 'Failed to add question. Please try again.';
        $message_type = 'error';
    }
}

// Handle bulk CSV upload
if (isset($_POST['bulk_upload_questions']) && wp_verify_nonce($_POST['bulk_nonce'], 'zonatech_bulk_upload')) {
    if (!empty($_FILES['csv_file']['tmp_name'])) {
        $file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file, 'r');
        $header = fgetcsv($handle); // Skip header row
        
        $table_questions = $wpdb->prefix . 'zonatech_questions';
        $success_count = 0;
        $error_count = 0;
        
        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) >= 9) {
                $result = $wpdb->insert($table_questions, array(
                    'exam_type' => sanitize_text_field($row[0]),
                    'subject' => sanitize_text_field($row[1]),
                    'year' => intval($row[2]),
                    'question_text' => sanitize_textarea_field($row[3]),
                    'option_a' => sanitize_text_field($row[4]),
                    'option_b' => sanitize_text_field($row[5]),
                    'option_c' => sanitize_text_field($row[6]),
                    'option_d' => sanitize_text_field($row[7]),
                    'correct_answer' => sanitize_text_field($row[8]),
                    'explanation' => isset($row[9]) ? sanitize_textarea_field($row[9]) : '',
                    'created_at' => current_time('mysql')
                ));
                
                if ($result) {
                    $success_count++;
                } else {
                    $error_count++;
                }
            }
        }
        fclose($handle);
        
        $message = "Bulk upload completed: $success_count questions added successfully, $error_count failed.";
        $message_type = $error_count > 0 ? 'warning' : 'success';
    } else {
        $message = 'Please select a CSV file to upload.';
        $message_type = 'error';
    }
}

// Handle DOC/PDF upload with intelligent parsing
if (isset($_POST['doc_upload_questions']) && wp_verify_nonce($_POST['doc_nonce'], 'zonatech_doc_upload')) {
    $exam_type = sanitize_text_field($_POST['doc_exam_type']);
    $subject = sanitize_text_field($_POST['doc_subject']);
    $year = intval($_POST['doc_year']);
    
    if (!empty($_FILES['doc_file']['tmp_name']) && $exam_type && $subject && $year) {
        $file = $_FILES['doc_file'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        // Read file content
        $content = '';
        
        if ($file_ext === 'txt') {
            $content = file_get_contents($file['tmp_name']);
        } elseif ($file_ext === 'docx') {
            // Parse DOCX file (ZIP with XML)
            $zip = new ZipArchive();
            if ($zip->open($file['tmp_name']) === TRUE) {
                $xml = $zip->getFromName('word/document.xml');
                $zip->close();
                
                // Extract text from XML
                $xml = str_replace('</w:p>', "\n", $xml);
                $xml = str_replace('</w:t>', ' ', $xml);
                $content = strip_tags($xml);
            }
        } elseif ($file_ext === 'doc') {
            // Basic DOC parsing (works for simple documents)
            $content = '';
            $fh = fopen($file['tmp_name'], 'r');
            if ($fh) {
                while (!feof($fh)) {
                    $content .= fread($fh, 8192);
                }
                fclose($fh);
                // Filter out binary/special characters
                $content = preg_replace('/[^\x20-\x7E\n\r]/', '', $content);
            }
        } elseif ($file_ext === 'pdf') {
            // Basic PDF text extraction
            $content = file_get_contents($file['tmp_name']);
            // Extract text between stream tags
            preg_match_all('/stream\s*(.*?)\s*endstream/s', $content, $matches);
            $text_parts = array();
            foreach ($matches[1] as $part) {
                // Try to decode if it's compressed
                $decoded = @gzuncompress($part);
                if ($decoded) {
                    $part = $decoded;
                }
                // Extract text from BT/ET blocks
                preg_match_all('/\((.*?)\)/', $part, $text_matches);
                $text_parts = array_merge($text_parts, $text_matches[1]);
            }
            $content = implode(' ', $text_parts);
        }
        
        // Clean up content
        $content = trim($content);
        $content = preg_replace('/\r\n/', "\n", $content);
        $content = preg_replace('/\r/', "\n", $content);
        
        // Intelligent question parsing
        $table_questions = $wpdb->prefix . 'zonatech_questions';
        $success_count = 0;
        $error_count = 0;
        
        // Split by question numbers (1., 2., 3., etc. or Q1, Q2, etc. or Question 1, etc.)
        $patterns = array(
            '/(?:^|\n)\s*(\d+)\s*[.\)]\s*/m',  // 1. or 1)
            '/(?:^|\n)\s*Q\.?\s*(\d+)[.\):\s]/im',  // Q1 or Q.1 or Q1:
            '/(?:^|\n)\s*Question\s*(\d+)[.\):\s]/im',  // Question 1
        );
        
        $questions_raw = array();
        foreach ($patterns as $pattern) {
            $parts = preg_split($pattern, $content, -1, PREG_SPLIT_NO_EMPTY);
            if (count($parts) > 1) {
                $questions_raw = $parts;
                break;
            }
        }
        
        // If no pattern matched, try splitting by double newlines
        if (empty($questions_raw)) {
            $questions_raw = preg_split('/\n\s*\n/', $content);
        }
        
        foreach ($questions_raw as $q_block) {
            $q_block = trim($q_block);
            if (strlen($q_block) < 20) continue; // Skip too short blocks
            
            // Try to parse question and options
            $question_text = '';
            $options = array('A' => '', 'B' => '', 'C' => '', 'D' => '');
            $correct_answer = '';
            
            // Pattern to find options
            $option_pattern = '/(?:^|\n)\s*([A-D])\s*[.\):\s]\s*(.+?)(?=(?:\n\s*[A-D]\s*[.\):\s])|$)/is';
            preg_match_all($option_pattern, $q_block, $opt_matches, PREG_SET_ORDER);
            
            if (!empty($opt_matches)) {
                // Extract question text (everything before first option)
                $first_opt_pos = strpos($q_block, $opt_matches[0][0]);
                if ($first_opt_pos !== false && $first_opt_pos > 0) {
                    $question_text = trim(substr($q_block, 0, $first_opt_pos));
                }
                
                // Extract options
                foreach ($opt_matches as $match) {
                    $letter = strtoupper($match[1]);
                    $text = trim($match[2]);
                    // Remove answer indicator if present
                    if (preg_match('/\*+\s*$/', $text) || preg_match('/\(correct\)/i', $text) || preg_match('/✓|√/', $text)) {
                        $correct_answer = $letter;
                        $text = preg_replace('/\*+\s*$/', '', $text);
                        $text = preg_replace('/\(correct\)/i', '', $text);
                        $text = preg_replace('/[✓√]/', '', $text);
                    }
                    $options[$letter] = trim($text);
                }
            }
            
            // Check for answer at the end of block (Answer: A or Ans: B)
            if (empty($correct_answer)) {
                if (preg_match('/(?:answer|ans)[:\s]*([A-D])/i', $q_block, $ans_match)) {
                    $correct_answer = strtoupper($ans_match[1]);
                }
            }
            
            // Only insert if we have question text and at least 2 options
            if (!empty($question_text) && strlen($options['A']) > 0 && strlen($options['B']) > 0) {
                $result = $wpdb->insert($table_questions, array(
                    'exam_type' => $exam_type,
                    'subject' => $subject,
                    'year' => $year,
                    'question_text' => sanitize_textarea_field($question_text),
                    'option_a' => sanitize_text_field($options['A']),
                    'option_b' => sanitize_text_field($options['B']),
                    'option_c' => sanitize_text_field($options['C']),
                    'option_d' => sanitize_text_field($options['D']),
                    'correct_answer' => $correct_answer ?: 'A',
                    'explanation' => '',
                    'created_at' => current_time('mysql')
                ));
                
                if ($result) {
                    $success_count++;
                } else {
                    $error_count++;
                }
            }
        }
        
        if ($success_count > 0) {
            $message = "Document parsed: $success_count questions extracted and added successfully!";
            $message_type = 'success';
        } else {
            $message = "Could not parse questions from the document. Please ensure your document follows a clear format with numbered questions and lettered options (A, B, C, D).";
            $message_type = 'error';
        }
    } else {
        $message = 'Please select a file and fill in all required fields (Exam Type, Subject, Year).';
        $message_type = 'error';
    }
}

// Handle scratch card generation
if (isset($_POST['generate_cards']) && wp_verify_nonce($_POST['cards_nonce'], 'zonatech_generate_cards')) {
    $card_type = sanitize_text_field($_POST['card_type']);
    $quantity = intval($_POST['quantity']);
    
    if ($quantity > 0 && $quantity <= 100) {
        $table_cards = $wpdb->prefix . 'zonatech_scratch_cards';
        $generated = 0;
        
        for ($i = 0; $i < $quantity; $i++) {
            $pin = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 12));
            $serial = 'ZT' . date('Ymd') . strtoupper(substr(md5(mt_rand()), 0, 6));
            
            $result = $wpdb->insert($table_cards, array(
                'card_type' => $card_type,
                'serial_number' => $serial,
                'pin' => $pin,
                'status' => 'available',
                'created_at' => current_time('mysql')
            ));
            
            if ($result) $generated++;
        }
        
        $message = "$generated $card_type scratch cards generated successfully!";
        $message_type = 'success';
    } else {
        $message = 'Please enter a valid quantity (1-100).';
        $message_type = 'error';
    }
}

// Handle Paystack settings update
if (isset($_POST['save_paystack_settings']) && wp_verify_nonce($_POST['paystack_nonce'], 'zonatech_save_paystack')) {
    $public_key = sanitize_text_field($_POST['paystack_public_key']);
    $secret_key = sanitize_text_field($_POST['paystack_secret_key']);
    
    // Don't update secret key if it's the masked placeholder
    $skip_secret_update = ($secret_key === '••••••••••••••••' || empty($secret_key));
    
    // Validate key format
    $valid = true;
    if (!empty($public_key) && !preg_match('/^pk_(test|live)_[a-zA-Z0-9]+$/', $public_key)) {
        $message = 'Invalid public key format. Key should start with pk_test_ or pk_live_ followed by alphanumeric characters';
        $message_type = 'error';
        $valid = false;
    }
    if (!$skip_secret_update && !empty($secret_key) && !preg_match('/^sk_(test|live)_[a-zA-Z0-9]+$/', $secret_key)) {
        $message = 'Invalid secret key format. Key should start with sk_test_ or sk_live_ followed by alphanumeric characters';
        $message_type = 'error';
        $valid = false;
    }
    
    if ($valid) {
        update_option('zonatech_paystack_public_key', $public_key);
        if (!$skip_secret_update) {
            update_option('zonatech_paystack_secret_key', $secret_key);
        }
        $message = 'Paystack API keys updated successfully!';
        $message_type = 'success';
    }
}

// Handle OtaPay settings update
if (isset($_POST['save_otapay_settings']) && wp_verify_nonce($_POST['otapay_nonce'], 'zonatech_save_otapay')) {
    $otapay_api_key = sanitize_text_field($_POST['otapay_api_key']);
    $otapay_enabled = isset($_POST['otapay_enabled']) ? '1' : '0';
    
    // Don't update API key if it's the masked placeholder
    $skip_key_update = ($otapay_api_key === '••••••••••••••••' || empty($otapay_api_key));
    
    if (!$skip_key_update) {
        update_option('zonatech_otapay_api_key', $otapay_api_key);
    }
    update_option('zonatech_otapay_enabled', $otapay_enabled);
    
    $message = 'OtaPay settings updated successfully!';
    $message_type = 'success';
}

// Get current Paystack settings
$paystack_public_key = get_option('zonatech_paystack_public_key', '');
$paystack_secret_key = get_option('zonatech_paystack_secret_key', '');
$is_test_mode = strpos($paystack_public_key, 'pk_test_') === 0;

// Get current OtaPay settings
$otapay_api_key = get_option('zonatech_otapay_api_key', '');
$otapay_enabled = get_option('zonatech_otapay_enabled', '0');

// Get statistics
$table_purchases = $wpdb->prefix . 'zonatech_purchases';
$table_questions = $wpdb->prefix . 'zonatech_questions';
$table_quiz = $wpdb->prefix . 'zonatech_quiz_results';
$table_cards = $wpdb->prefix . 'zonatech_scratch_cards';
$table_nin = $wpdb->prefix . 'zonatech_nin_requests';
$table_feedback = $wpdb->prefix . 'zonatech_feedback';
$table_activity = $wpdb->prefix . 'zonatech_activity_log';

// Revenue statistics
$today_revenue = $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(amount), 0) FROM $table_purchases WHERE status = 'completed' AND DATE(created_at) = %s",
    date('Y-m-d')
)) ?? 0;

$this_week_revenue = $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(amount), 0) FROM $table_purchases WHERE status = 'completed' AND created_at >= %s",
    date('Y-m-d', strtotime('-7 days'))
)) ?? 0;

$this_month_revenue = $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(amount), 0) FROM $table_purchases WHERE status = 'completed' AND MONTH(created_at) = %d AND YEAR(created_at) = %d",
    date('n'), date('Y')
)) ?? 0;

$total_revenue = $wpdb->get_var(
    "SELECT COALESCE(SUM(amount), 0) FROM $table_purchases WHERE status = 'completed'"
) ?? 0;

// User statistics
$total_users = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}") ?? 0;
$new_users_today = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->users} WHERE DATE(user_registered) = %s",
    date('Y-m-d')
)) ?? 0;
$new_users_week = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered >= %s",
    date('Y-m-d', strtotime('-7 days'))
)) ?? 0;

// Questions count
$total_questions = $wpdb->get_var("SELECT COUNT(*) FROM $table_questions") ?? 0;
$question_stats = $wpdb->get_results("SELECT exam_type, COUNT(*) as count FROM $table_questions GROUP BY exam_type");

// Quizzes taken
$total_quizzes = $wpdb->get_var("SELECT COUNT(*) FROM $table_quiz") ?? 0;
$quizzes_today = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM $table_quiz WHERE DATE(created_at) = %s",
    date('Y-m-d')
)) ?? 0;

// Pending items
$pending_purchases = $wpdb->get_var("SELECT COUNT(*) FROM $table_purchases WHERE status = 'pending'") ?? 0;

// Recent purchases
$recent_purchases = $wpdb->get_results($wpdb->prepare(
    "SELECT p.*, u.display_name, u.user_email 
     FROM $table_purchases p 
     LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID 
     ORDER BY p.created_at DESC 
     LIMIT %d",
    10
));

// Top subjects
$top_subjects = $wpdb->get_results(
    "SELECT item_name, COUNT(*) as count, SUM(amount) as revenue 
     FROM $table_purchases 
     WHERE status = 'completed' AND purchase_type = 'subject'
     GROUP BY item_name 
     ORDER BY count DESC 
     LIMIT 5"
);

// Available scratch cards
$available_cards = $wpdb->get_results(
    "SELECT card_type, COUNT(*) as count FROM $table_cards WHERE status = 'available' GROUP BY card_type"
);

// Recent users
$recent_users = $wpdb->get_results($wpdb->prepare(
    "SELECT ID, display_name, user_email, user_registered FROM {$wpdb->users} ORDER BY user_registered DESC LIMIT %d",
    10
));

// Recent feedback (check if table exists first)
$recent_feedback = array();
if ($wpdb->get_var("SHOW TABLES LIKE '$table_feedback'") == $table_feedback) {
    $recent_feedback = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_feedback ORDER BY created_at DESC LIMIT %d",
        10
    ));
}

// Activity log
$recent_activities = $wpdb->get_results($wpdb->prepare(
    "SELECT a.*, u.display_name FROM $table_activity a 
     LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID 
     ORDER BY a.created_at DESC LIMIT %d",
    10
));

$current_user = wp_get_current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ZonaTech NG</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ZONATECH_PLUGIN_URL; ?>assets/css/main.css">
    <link rel="stylesheet" href="<?php echo ZONATECH_PLUGIN_URL; ?>assets/css/dashboard.css">
    <style>
        :root {
            --primary: #8b5cf6;
            --primary-dark: #7c3aed;
            --primary-light: #a78bfa;
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #3b82f6;
            --dark: #1f2937;
            --light: #f9fafb;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f0f0f 0%, #1a1a2e 50%, #16213e 100%);
            min-height: 100vh;
            color: #ffffff;
        }
        
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .admin-sidebar {
            width: 280px;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(20px);
            border-right: 1px solid rgba(139, 92, 246, 0.2);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        
        .admin-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid rgba(139, 92, 246, 0.2);
        }
        
        .admin-logo a {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .admin-logo img {
            width: 70px;
            height: 70px;
            border-radius: 12px;
            object-fit: contain;
            border: 2px solid rgba(139, 92, 246, 0.5);
            padding: 4px;
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
            transition: all 0.3s ease;
        }
        
        .admin-logo img:hover {
            border-color: rgba(139, 92, 246, 0.8);
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
        }
        
        /* Logo fallback when image is missing */
        .admin-logo-icon {
            width: 70px;
            height: 70px;
            border-radius: 12px;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: #ffffff;
            border: 2px solid rgba(139, 92, 246, 0.3);
            transition: all 0.3s ease;
            flex-shrink: 0;
        }
        
        .admin-logo-icon:hover {
            border-color: rgba(139, 92, 246, 0.8);
            transform: scale(1.05);
        }
        
        .admin-logo-text {
            flex: 1;
            min-width: 0;
        }
        
        .admin-logo h2 {
            font-size: 16px;
            font-weight: 700;
            background: linear-gradient(135deg, #8b5cf6, #a78bfa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0;
            line-height: 1.3;
        }
        
        .admin-logo span {
            font-size: 11px;
            color: rgba(255, 255, 255, 0.5);
            display: block;
            margin-top: 2px;
        }
        
        .admin-nav {
            list-style: none;
        }
        
        .admin-nav li {
            margin-bottom: 5px;
        }
        
        .admin-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background: rgba(139, 92, 246, 0.2);
            color: #ffffff;
        }
        
        .admin-nav a.active {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(167, 139, 250, 0.2));
            border-left: 3px solid #8b5cf6;
        }
        
        .admin-nav i {
            width: 20px;
            text-align: center;
        }
        
        .nav-divider {
            height: 1px;
            background: rgba(139, 92, 246, 0.2);
            margin: 20px 0;
        }
        
        .admin-user {
            margin-top: auto;
            padding: 15px;
            background: rgba(139, 92, 246, 0.1);
            border-radius: 12px;
            margin-top: 30px;
        }
        
        .admin-user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .admin-user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #8b5cf6, #a78bfa);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .admin-user-details h4 {
            font-size: 14px;
            font-weight: 600;
        }
        
        .admin-user-details span {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
        }
        
        /* Main Content */
        .admin-main {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            padding-right: 40px;
            max-width: calc(100vw - 280px);
            overflow-x: hidden;
            box-sizing: border-box;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .admin-header h1 {
            font-size: 28px;
            font-weight: 700;
        }
        
        .admin-header-actions {
            display: flex;
            gap: 15px;
        }
        
        .btn-admin {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none !important;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .btn-admin:hover {
            text-decoration: none !important;
        }
        
        .btn-admin-primary {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            background-size: 200% 200%;
            color: #ffffff;
            animation: btn-glow 3s ease-in-out infinite;
        }
        
        .btn-admin-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(139, 92, 246, 0.4);
            animation: btn-shimmer 1.5s ease-in-out infinite, btn-glow 1.5s ease-in-out infinite;
        }
        
        @keyframes btn-shimmer {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
        }
        
        @keyframes btn-glow {
            0%, 100% { box-shadow: 0 0 15px rgba(139, 92, 246, 0.3); }
            50% { box-shadow: 0 0 30px rgba(139, 92, 246, 0.6); }
        }
        
        .btn-admin-outline {
            background: transparent;
            border: 1px solid rgba(139, 92, 246, 0.5);
            color: #ffffff;
        }
        
        .btn-admin-outline:hover {
            background: rgba(139, 92, 246, 0.1);
            border-color: rgba(139, 92, 246, 0.8);
        }
        
        /* Remove all underlines from links and buttons */
        a, a:hover, a:focus, a:active,
        .admin-nav a, .admin-nav a:hover,
        .btn-admin, .btn-admin:hover,
        button, button:hover {
            text-decoration: none !important;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 16px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(139, 92, 246, 0.5);
            box-shadow: 0 10px 40px rgba(139, 92, 246, 0.2);
        }
        
        .stat-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .stat-card-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        
        .stat-card-icon.revenue { background: rgba(139, 92, 246, 0.2); color: #8b5cf6; }
        .stat-card-icon.users { background: rgba(16, 185, 129, 0.2); color: #10b981; }
        .stat-card-icon.questions { background: rgba(59, 130, 246, 0.2); color: #3b82f6; }
        .stat-card-icon.pending { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
        
        .stat-card-change {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 20px;
        }
        
        .stat-card-change.positive {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
        }
        
        .stat-card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-card-label {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.6);
        }
        
        /* Section */
        .admin-section {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 25px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-header h2 {
            font-size: 18px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-header h2 i {
            color: #8b5cf6;
        }
        
        /* Tables */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .admin-table th {
            text-align: left;
            padding: 12px 15px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.5);
            border-bottom: 1px solid rgba(139, 92, 246, 0.2);
        }
        
        .admin-table td {
            padding: 15px;
            font-size: 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .admin-table tr:hover td {
            background: rgba(139, 92, 246, 0.05);
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-badge.completed {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
        }
        
        .status-badge.pending {
            background: rgba(245, 158, 11, 0.2);
            color: #f59e0b;
        }
        
        .status-badge.failed {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }
        
        /* Grid Layouts */
        .two-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }
        
        .three-columns {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        
        /* Cards Info */
        .card-info {
            background: rgba(139, 92, 246, 0.1);
            border-radius: 12px;
            padding: 15px;
            text-align: center;
        }
        
        .card-info h4 {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .card-info .value {
            font-size: 24px;
            font-weight: 700;
            color: #8b5cf6;
        }
        
        /* Feedback Card */
        .feedback-card {
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .feedback-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .feedback-rating {
            color: #f59e0b;
        }
        
        .feedback-message {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.5;
        }
        
        .feedback-meta {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
            margin-top: 10px;
        }
        
        /* User Avatar */
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: linear-gradient(135deg, #8b5cf6, #a78bfa);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 600;
        }
        
        .user-details {
            font-size: 14px;
        }
        
        .user-details small {
            display: block;
            color: rgba(255, 255, 255, 0.5);
            font-size: 12px;
        }
        
        /* Hamburger Menu for Mobile */
        .mobile-menu-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 200;
            width: 45px;
            height: 45px;
            background: rgba(139, 92, 246, 0.2);
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 12px;
            cursor: pointer;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }
        
        .mobile-menu-toggle span {
            width: 20px;
            height: 2px;
            background: #ffffff;
            transition: all 0.3s ease;
        }
        
        /* Responsive */
        @media (max-width: 1400px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .two-columns {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-toggle {
                display: flex;
            }
            
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .admin-sidebar.open {
                transform: translateX(0);
            }
            
            .admin-main {
                margin-left: 0;
                padding: 80px 15px 30px;
                max-width: 100vw;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .three-columns {
                grid-template-columns: 1fr;
            }
            
            .admin-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .admin-header h1 {
                font-size: 22px;
            }
        }
        
        /* Modal Styles */
        .admin-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            overflow-y: auto;
            padding: 40px 20px;
        }
        
        .admin-modal.active {
            display: flex;
            align-items: flex-start;
            justify-content: center;
        }
        
        .admin-modal-content {
            background: linear-gradient(135deg, rgba(30, 30, 50, 0.98), rgba(20, 20, 35, 0.98));
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 20px;
            padding: 30px;
            max-width: 700px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
        }
        
        .admin-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(139, 92, 246, 0.2);
        }
        
        .admin-modal-header h2 {
            font-size: 22px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #ffffff;
        }
        
        .admin-modal-header h2 i {
            color: #8b5cf6;
        }
        
        .admin-modal-close {
            width: 40px;
            height: 40px;
            border: none;
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border-radius: 10px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        
        .admin-modal-close:hover {
            background: rgba(239, 68, 68, 0.4);
        }
        
        /* Form Styles */
        .admin-form-group {
            margin-bottom: 20px;
        }
        
        .admin-form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 8px;
        }
        
        .admin-form-group input,
        .admin-form-group select,
        .admin-form-group textarea {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 10px;
            color: #ffffff;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
        }
        
        .admin-form-group input:focus,
        .admin-form-group select:focus,
        .admin-form-group textarea:focus {
            outline: none;
            border-color: #8b5cf6;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2);
        }
        
        .admin-form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .admin-form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .admin-form-row-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        
        @media (max-width: 600px) {
            .admin-form-row, .admin-form-row-3 {
                grid-template-columns: 1fr;
            }
        }
        
        .admin-form-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .admin-form-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.4);
        }
        
        /* Tabs */
        .admin-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .admin-tab {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 10px;
            color: rgba(255, 255, 255, 0.7);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        
        .admin-tab:hover, .admin-tab.active {
            background: rgba(139, 92, 246, 0.2);
            border-color: rgba(139, 92, 246, 0.5);
            color: #ffffff;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* File Upload */
        .file-upload-area {
            border: 2px dashed rgba(139, 92, 246, 0.4);
            border-radius: 12px;
            padding: 40px 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }
        
        .file-upload-area:hover {
            border-color: #8b5cf6;
            background: rgba(139, 92, 246, 0.1);
        }
        
        .file-upload-area i {
            font-size: 40px;
            color: #8b5cf6;
            margin-bottom: 15px;
        }
        
        .file-upload-area p {
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 10px;
        }
        
        .file-upload-area small {
            color: rgba(255, 255, 255, 0.5);
            font-size: 12px;
        }
        
        .file-upload-area input[type="file"] {
            display: none;
        }
        
        /* Message Alert */
        .admin-alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .admin-alert.success {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid rgba(16, 185, 129, 0.4);
            color: #10b981;
        }
        
        .admin-alert.error {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #ef4444;
        }
        
        .admin-alert.warning {
            background: rgba(245, 158, 11, 0.2);
            border: 1px solid rgba(245, 158, 11, 0.4);
            color: #f59e0b;
        }
        
        /* Download Link */
        .download-template {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            background: rgba(59, 130, 246, 0.2);
            border: 1px solid rgba(59, 130, 246, 0.4);
            border-radius: 8px;
            color: #3b82f6;
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .download-template:hover {
            background: rgba(59, 130, 246, 0.3);
        }
        
        /* Section Containers */
        .admin-section-container {
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Mobile Menu Toggle -->
        <button class="mobile-menu-toggle" onclick="toggleSidebar()">
            <span></span>
            <span></span>
            <span></span>
        </button>
        
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="admin-logo">
                <a href="<?php echo site_url(); ?>">
                    <img src="<?php echo ZONATECH_PLUGIN_URL; ?>assets/images/logo-medium.png" alt="ZonaTech NG" class="admin-logo-img">
                </a>
                <div class="admin-logo-text">
                    <h2>ZonaTech NG</h2>
                    <span>Admin Dashboard</span>
                </div>
            </div>
            
            <ul class="admin-nav">
                <li><a href="#dashboard" class="active" onclick="switchSection('dashboard', this); return false;"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="#users" onclick="switchSection('users', this); return false;"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="#purchases" onclick="switchSection('purchases', this); return false;"><i class="fas fa-shopping-cart"></i> Purchases</a></li>
                <li><a href="#questions" onclick="switchSection('questions', this); return false;"><i class="fas fa-book"></i> Questions</a></li>
                <li><a href="#nin-requests" onclick="switchSection('nin-requests', this); return false;"><i class="fas fa-id-card"></i> NIN Requests</a></li>
                <li><a href="#feedback" onclick="switchSection('feedback', this); return false;"><i class="fas fa-comments"></i> Feedback</a></li>
                
                <div class="nav-divider"></div>
                
                <li><a href="#" onclick="openModal('addQuestionModal'); return false;"><i class="fas fa-plus-circle"></i> Add Questions</a></li>
                <li><a href="#" onclick="openModal('manageCardsModal'); return false;"><i class="fas fa-ticket-alt"></i> Manage Cards</a></li>
                <li><a href="#" onclick="openModal('settingsModal'); return false;"><i class="fas fa-cog"></i> Settings</a></li>
                
                <div class="nav-divider"></div>
                
                <li><a href="<?php echo site_url('/zonatech-dashboard/'); ?>"><i class="fas fa-user"></i> User Dashboard</a></li>
                <li><a href="<?php echo site_url(); ?>"><i class="fas fa-home"></i> View Site</a></li>
                <li><a href="<?php echo wp_logout_url(site_url()); ?>"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
            
            <div class="admin-user">
                <div class="admin-user-info">
                    <div class="admin-user-avatar">
                        <?php echo strtoupper(substr($current_user->display_name, 0, 1)); ?>
                    </div>
                    <div class="admin-user-details">
                        <h4><?php echo esc_html($current_user->display_name); ?></h4>
                        <span>Administrator</span>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <?php if (!empty($message)): ?>
            <div class="admin-alert <?php echo esc_attr($message_type); ?>">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : ($message_type === 'warning' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
                <?php echo esc_html($message); ?>
            </div>
            <?php endif; ?>
            
            <!-- Dashboard Section -->
            <div id="dashboard-section" class="admin-section-container">
            <div class="admin-header">
                <h1><i class="fas fa-chart-line"></i> Dashboard Overview</h1>
                <div class="admin-header-actions">
                    <button onclick="openModal('addQuestionModal')" class="btn-admin btn-admin-primary">
                        <i class="fas fa-plus"></i> Add Question
                    </button>
                    <button onclick="openModal('manageCardsModal')" class="btn-admin btn-admin-outline">
                        <i class="fas fa-ticket-alt"></i> Add Cards
                    </button>
                </div>
            </div>
            
            <!-- Revenue Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon revenue"><i class="fas fa-calendar-day"></i></div>
                        <span class="stat-card-change positive">Today</span>
                    </div>
                    <div class="stat-card-value">₦<?php echo number_format($today_revenue); ?></div>
                    <div class="stat-card-label">Today's Revenue</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon revenue"><i class="fas fa-calendar-week"></i></div>
                        <span class="stat-card-change positive">7 Days</span>
                    </div>
                    <div class="stat-card-value">₦<?php echo number_format($this_week_revenue); ?></div>
                    <div class="stat-card-label">This Week</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon revenue"><i class="fas fa-calendar-alt"></i></div>
                        <span class="stat-card-change positive">Month</span>
                    </div>
                    <div class="stat-card-value">₦<?php echo number_format($this_month_revenue); ?></div>
                    <div class="stat-card-label">This Month</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon revenue"><i class="fas fa-vault"></i></div>
                    </div>
                    <div class="stat-card-value">₦<?php echo number_format($total_revenue); ?></div>
                    <div class="stat-card-label">Total Revenue</div>
                </div>
            </div>
            
            <!-- Platform Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon users"><i class="fas fa-users"></i></div>
                        <span class="stat-card-change positive">+<?php echo $new_users_today; ?> today</span>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($total_users); ?></div>
                    <div class="stat-card-label">Total Users</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon questions"><i class="fas fa-book"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($total_questions); ?></div>
                    <div class="stat-card-label">Total Questions</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon questions"><i class="fas fa-clipboard-check"></i></div>
                        <span class="stat-card-change positive">+<?php echo $quizzes_today; ?> today</span>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($total_quizzes); ?></div>
                    <div class="stat-card-label">Quizzes Taken</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-icon pending"><i class="fas fa-clock"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($pending_purchases); ?></div>
                    <div class="stat-card-label">Pending Payments</div>
                </div>
            </div>
            
            <!-- Questions by Exam Type -->
            <div class="admin-section">
                <div class="section-header">
                    <h2><i class="fas fa-book-open"></i> Questions by Exam Type</h2>
                </div>
                <div class="three-columns">
                    <?php 
                    $exam_colors = array('jamb' => '#8b5cf6', 'waec' => '#10b981', 'neco' => '#f59e0b');
                    foreach ($question_stats as $stat): 
                        $color = $exam_colors[strtolower($stat->exam_type)] ?? '#6b7280';
                    ?>
                    <div class="card-info" style="border-left: 4px solid <?php echo $color; ?>;">
                        <h4><?php echo strtoupper(esc_html($stat->exam_type)); ?></h4>
                        <div class="value"><?php echo number_format($stat->count); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div class="two-columns">
                <!-- Recent Purchases -->
                <div class="admin-section" id="purchases">
                    <div class="section-header">
                        <h2><i class="fas fa-shopping-cart"></i> Recent Purchases</h2>
                        <span class="btn-admin btn-admin-outline" style="opacity: 0.7;">Showing Latest 10</span>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Item</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_purchases)): ?>
                                <?php foreach ($recent_purchases as $purchase): ?>
                                <tr>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar"><?php echo strtoupper(substr($purchase->display_name ?? 'U', 0, 1)); ?></div>
                                            <div class="user-details">
                                                <?php echo esc_html($purchase->display_name ?? 'Unknown'); ?>
                                                <small><?php echo date('M j', strtotime($purchase->created_at)); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo esc_html($purchase->item_name); ?></td>
                                    <td>₦<?php echo number_format($purchase->amount); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo esc_attr($purchase->status); ?>">
                                            <?php echo ucfirst($purchase->status); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align: center; color: rgba(255,255,255,0.5);">No purchases yet</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Recent Users -->
                <div class="admin-section" id="users">
                    <div class="section-header">
                        <h2><i class="fas fa-users"></i> Recent Users</h2>
                        <span class="btn-admin btn-admin-outline" style="opacity: 0.7;">Showing Latest 10</span>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_users)): ?>
                                <?php foreach ($recent_users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar"><?php echo strtoupper(substr($user->display_name, 0, 1)); ?></div>
                                            <span><?php echo esc_html($user->display_name); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo esc_html($user->user_email); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($user->user_registered)); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" style="text-align: center; color: rgba(255,255,255,0.5);">No users yet</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- More Stats -->
            <div class="two-columns">
                <!-- Top Selling Subjects -->
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-star"></i> Top Selling Subjects</h2>
                    </div>
                    <?php if (!empty($top_subjects)): ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Sales</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_subjects as $subject): ?>
                            <tr>
                                <td><?php echo esc_html($subject->item_name); ?></td>
                                <td><?php echo number_format($subject->count); ?></td>
                                <td>₦<?php echo number_format($subject->revenue); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <p style="text-align: center; color: rgba(255,255,255,0.5);">No subject sales yet</p>
                    <?php endif; ?>
                </div>
                
                <!-- Scratch Cards -->
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-ticket-alt"></i> Available Scratch Cards</h2>
                        <button onclick="openModal('manageCardsModal')" class="btn-admin btn-admin-outline">Add More</button>
                    </div>
                    <?php if (!empty($available_cards)): ?>
                    <div class="three-columns">
                        <?php foreach ($available_cards as $card): ?>
                        <div class="card-info">
                            <h4><?php echo strtoupper(esc_html($card->card_type)); ?></h4>
                            <div class="value"><?php echo number_format($card->count); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p style="text-align: center; color: rgba(255,255,255,0.5);">No scratch cards available. <a href="#" onclick="openModal('manageCardsModal'); return false;" style="color: #8b5cf6;">Add some</a></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Recent Feedback -->
            <div class="admin-section" id="feedback">
                <div class="section-header">
                    <h2><i class="fas fa-comments"></i> Recent Feedback</h2>
                    <span class="btn-admin btn-admin-outline" style="opacity: 0.7;">Showing Latest 5</span>
                </div>
                <?php if (!empty($recent_feedback)): ?>
                    <?php foreach ($recent_feedback as $fb): ?>
                    <div class="feedback-card">
                        <div class="feedback-card-header">
                            <div class="user-info">
                                <div class="user-avatar"><?php echo strtoupper(substr($fb->name, 0, 1)); ?></div>
                                <div class="user-details">
                                    <?php echo esc_html($fb->name); ?>
                                    <small><?php echo esc_html($fb->subject); ?></small>
                                </div>
                            </div>
                            <div class="feedback-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa<?php echo $i <= $fb->rating ? 's' : 'r'; ?> fa-star"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <p class="feedback-message"><?php echo esc_html(substr($fb->message, 0, 200)); ?><?php echo strlen($fb->message) > 200 ? '...' : ''; ?></p>
                        <div class="feedback-meta">
                            <i class="fas fa-envelope"></i> <?php echo esc_html($fb->email); ?> &bull; 
                            <i class="fas fa-clock"></i> <?php echo date('M j, Y g:i A', strtotime($fb->created_at)); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align: center; color: rgba(255,255,255,0.5);">No feedback yet</p>
                <?php endif; ?>
            </div>
            
            <!-- Recent Activity -->
            <div class="admin-section">
                <div class="section-header">
                    <h2><i class="fas fa-history"></i> Recent Activity</h2>
                </div>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Activity</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_activities)): ?>
                            <?php foreach ($recent_activities as $activity): ?>
                            <tr>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar"><?php echo strtoupper(substr($activity->display_name ?? 'U', 0, 1)); ?></div>
                                        <span><?php echo esc_html($activity->display_name ?? 'Unknown'); ?></span>
                                    </div>
                                </td>
                                <td><?php echo esc_html($activity->action); ?></td>
                                <td><?php echo date('M j, g:i A', strtotime($activity->created_at)); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="3" style="text-align: center; color: rgba(255,255,255,0.5);">No recent activity</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div><!-- End Dashboard Section -->
            
            <!-- Users Section -->
            <div id="users-section" class="admin-section-container" style="display: none;">
                <div class="admin-header">
                    <h1><i class="fas fa-users"></i> Users Management</h1>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon users"><i class="fas fa-users"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($total_users); ?></div>
                        <div class="stat-card-label">Total Users</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon revenue"><i class="fas fa-user-plus"></i></div>
                            <span class="stat-card-change positive">Today</span>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($new_users_today); ?></div>
                        <div class="stat-card-label">New Today</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon questions"><i class="fas fa-user-check"></i></div>
                            <span class="stat-card-change positive">7 Days</span>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($new_users_week); ?></div>
                        <div class="stat-card-label">New This Week</div>
                    </div>
                </div>
                
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-list"></i> All Users</h2>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Registered</th>
                                <th>Purchases</th>
                                <th>Quizzes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $all_users = $wpdb->get_results($wpdb->prepare(
                                "SELECT ID, display_name, user_email, user_registered FROM {$wpdb->users} ORDER BY user_registered DESC LIMIT %d",
                                50
                            ));
                            foreach ($all_users as $u): 
                                $u_purchases = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_purchases WHERE user_id = %d AND status = 'completed'", $u->ID));
                                $u_quizzes = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_quiz WHERE user_id = %d", $u->ID));
                            ?>
                            <tr>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar"><?php echo strtoupper(substr($u->display_name, 0, 1)); ?></div>
                                        <div class="user-details"><?php echo esc_html($u->display_name); ?></div>
                                    </div>
                                </td>
                                <td><?php echo esc_html($u->user_email); ?></td>
                                <td><?php echo date('M j, Y', strtotime($u->user_registered)); ?></td>
                                <td><?php echo number_format($u_purchases); ?></td>
                                <td><?php echo number_format($u_quizzes); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- End Users Section -->
            
            <!-- Purchases Section -->
            <div id="purchases-section" class="admin-section-container" style="display: none;">
                <div class="admin-header">
                    <h1><i class="fas fa-shopping-cart"></i> Purchases Management</h1>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon revenue"><i class="fas fa-money-bill"></i></div>
                        </div>
                        <div class="stat-card-value">₦<?php echo number_format($total_revenue); ?></div>
                        <div class="stat-card-label">Total Revenue</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon pending"><i class="fas fa-clock"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($pending_purchases); ?></div>
                        <div class="stat-card-label">Pending</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon questions"><i class="fas fa-check-circle"></i></div>
                        </div>
                        <?php $completed_purchases = $wpdb->get_var("SELECT COUNT(*) FROM $table_purchases WHERE status = 'completed'") ?? 0; ?>
                        <div class="stat-card-value"><?php echo number_format($completed_purchases); ?></div>
                        <div class="stat-card-label">Completed</div>
                    </div>
                </div>
                
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-list"></i> All Purchases</h2>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Item</th>
                                <th>Amount</th>
                                <th>Reference</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $all_purchases = $wpdb->get_results($wpdb->prepare(
                                "SELECT p.*, u.display_name, u.user_email 
                                 FROM $table_purchases p 
                                 LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID 
                                 ORDER BY p.created_at DESC 
                                 LIMIT %d",
                                100
                            ));
                            foreach ($all_purchases as $p): 
                            ?>
                            <tr>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar"><?php echo strtoupper(substr($p->display_name ?? 'U', 0, 1)); ?></div>
                                        <div class="user-details"><?php echo esc_html($p->display_name ?? 'Unknown'); ?></div>
                                    </div>
                                </td>
                                <td><?php echo esc_html($p->item_name); ?></td>
                                <td>₦<?php echo number_format($p->amount); ?></td>
                                <td><code style="font-size: 11px;"><?php echo esc_html($p->reference); ?></code></td>
                                <td>
                                    <?php if ($p->status === 'completed'): ?>
                                        <span class="status-badge success">Completed</span>
                                    <?php elseif ($p->status === 'pending'): ?>
                                        <span class="status-badge warning">Pending</span>
                                    <?php else: ?>
                                        <span class="status-badge error"><?php echo esc_html($p->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($p->created_at)); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- End Purchases Section -->
            
            <!-- Questions Section -->
            <div id="questions-section" class="admin-section-container" style="display: none;">
                <div class="admin-header">
                    <h1><i class="fas fa-book"></i> Questions Management</h1>
                    <div class="admin-header-actions">
                        <button onclick="openModal('addQuestionModal')" class="btn-admin btn-admin-primary">
                            <i class="fas fa-plus"></i> Add Question
                        </button>
                    </div>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon questions"><i class="fas fa-book-open"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($total_questions); ?></div>
                        <div class="stat-card-label">Total Questions</div>
                    </div>
                    <?php foreach ($question_stats as $stat): 
                        $color = $exam_colors[strtolower($stat->exam_type)] ?? '#6b7280';
                    ?>
                    <div class="stat-card" style="border-left: 4px solid <?php echo $color; ?>;">
                        <div class="stat-card-header">
                            <div class="stat-card-icon" style="background: <?php echo $color; ?>20; color: <?php echo $color; ?>;"><i class="fas fa-graduation-cap"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($stat->count); ?></div>
                        <div class="stat-card-label"><?php echo strtoupper(esc_html($stat->exam_type)); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-list"></i> Recent Questions</h2>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Exam</th>
                                <th>Subject</th>
                                <th>Year</th>
                                <th>Question</th>
                                <th>Answer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $all_questions = $wpdb->get_results($wpdb->prepare(
                                "SELECT * FROM $table_questions ORDER BY created_at DESC LIMIT %d",
                                50
                            ));
                            foreach ($all_questions as $q): 
                            ?>
                            <tr>
                                <td><span class="status-badge" style="background: <?php echo $exam_colors[strtolower($q->exam_type)] ?? '#6b7280'; ?>20; color: <?php echo $exam_colors[strtolower($q->exam_type)] ?? '#6b7280'; ?>;"><?php echo strtoupper(esc_html($q->exam_type)); ?></span></td>
                                <td><?php echo esc_html($q->subject); ?></td>
                                <td><?php echo esc_html($q->year); ?></td>
                                <td style="max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo esc_html(substr($q->question_text, 0, 80)); ?>...</td>
                                <td><span class="status-badge success"><?php echo esc_html($q->correct_answer); ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- End Questions Section -->
            
            <!-- Feedback Section -->
            <div id="feedback-section" class="admin-section-container" style="display: none;">
                <div class="admin-header">
                    <h1><i class="fas fa-comments"></i> Feedback Management</h1>
                </div>
                
                <?php 
                $all_feedback = $wpdb->get_results($wpdb->prepare(
                    "SELECT f.*, u.display_name, u.user_email 
                     FROM $table_feedback f 
                     LEFT JOIN {$wpdb->users} u ON f.user_id = u.ID 
                     ORDER BY f.created_at DESC 
                     LIMIT %d",
                    50
                ));
                $feedback_count = count($all_feedback);
                ?>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon questions"><i class="fas fa-comments"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($feedback_count); ?></div>
                        <div class="stat-card-label">Total Feedback</div>
                    </div>
                </div>
                
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-list"></i> All Feedback</h2>
                    </div>
                    <?php if (!empty($all_feedback)): ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Type</th>
                                <th>Message</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_feedback as $fb): ?>
                            <tr>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar"><?php echo strtoupper(substr($fb->display_name ?? 'U', 0, 1)); ?></div>
                                        <div class="user-details"><?php echo esc_html($fb->display_name ?? 'Unknown'); ?></div>
                                    </div>
                                </td>
                                <td><span class="status-badge"><?php echo esc_html($fb->feedback_type ?? 'General'); ?></span></td>
                                <td style="max-width: 400px;"><?php echo esc_html(substr($fb->message ?? '', 0, 100)); ?>...</td>
                                <td><?php echo date('M j, Y g:i A', strtotime($fb->created_at)); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: rgba(255,255,255,0.5);">
                        <i class="fas fa-comments" style="font-size: 48px; margin-bottom: 15px;"></i>
                        <p>No feedback received yet</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div><!-- End Feedback Section -->
            
            <!-- NIN Requests Section -->
            <div id="nin-requests-section" class="admin-section-container" style="display: none;">
                <div class="admin-header">
                    <h1><i class="fas fa-id-card"></i> NIN Requests Management</h1>
                </div>
                
                <?php 
                // Get NIN requests
                $nin_requests = $wpdb->get_results(
                    "SELECT n.*, u.display_name, u.user_email, p.amount 
                     FROM $table_nin n 
                     LEFT JOIN {$wpdb->users} u ON n.user_id = u.ID 
                     LEFT JOIN $table_purchases p ON n.purchase_id = p.id
                     ORDER BY n.created_at DESC 
                     LIMIT 100"
                );
                $pending_nin = $wpdb->get_var("SELECT COUNT(*) FROM $table_nin WHERE status = 'paid'") ?? 0;
                $fulfilled_nin = $wpdb->get_var("SELECT COUNT(*) FROM $table_nin WHERE status = 'fulfilled'") ?? 0;
                ?>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon pending"><i class="fas fa-clock"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($pending_nin); ?></div>
                        <div class="stat-card-label">Pending Fulfillment</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card-header">
                            <div class="stat-card-icon users"><i class="fas fa-check-circle"></i></div>
                        </div>
                        <div class="stat-card-value"><?php echo number_format($fulfilled_nin); ?></div>
                        <div class="stat-card-label">Fulfilled</div>
                    </div>
                </div>
                
                <div class="admin-section">
                    <div class="section-header">
                        <h2><i class="fas fa-list"></i> All NIN Requests</h2>
                    </div>
                    <?php if (!empty($nin_requests)): ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Service</th>
                                <th>NIN</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($nin_requests as $req): 
                                $form_data = json_decode($req->form_data ?? '{}', true);
                                $service_names = array(
                                    'nin_slip_download' => 'Slip Download',
                                    'nin_modification' => 'Data Modification',
                                    'nin_dob_correction' => 'DOB Correction',
                                    'nin_slip' => 'Premium Slip',
                                    'nin_standard_slip' => 'Standard Slip'
                                );
                                $service_type = $req->service_type ?? 'nin_slip';
                                $service_name = $service_names[$service_type] ?? $service_type;
                            ?>
                            <tr>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar"><?php echo strtoupper(substr($req->display_name ?? 'U', 0, 1)); ?></div>
                                        <div class="user-details">
                                            <?php echo esc_html($req->display_name ?? 'Unknown'); ?>
                                            <small><?php echo esc_html($req->user_email ?? ''); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge" style="background: rgba(139, 92, 246, 0.2); color: #a78bfa;">
                                        <?php echo esc_html($service_name); ?>
                                    </span>
                                </td>
                                <td><code style="font-size: 12px;"><?php echo esc_html($req->nin_number); ?></code></td>
                                <td>₦<?php echo number_format($req->amount ?? 0); ?></td>
                                <td>
                                    <?php if ($req->status === 'fulfilled'): ?>
                                        <span class="status-badge completed"><i class="fas fa-check"></i> Fulfilled</span>
                                    <?php elseif ($req->status === 'paid'): ?>
                                        <span class="status-badge pending"><i class="fas fa-clock"></i> Pending</span>
                                    <?php else: ?>
                                        <span class="status-badge"><?php echo esc_html($req->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($req->created_at)); ?></td>
                                <td>
                                    <?php if ($req->status === 'paid'): ?>
                                        <button onclick="openFulfillModal(<?php echo $req->id; ?>, '<?php echo esc_js($req->display_name); ?>', '<?php echo esc_js($req->user_email); ?>', '<?php echo esc_js($req->nin_number); ?>', '<?php echo esc_js($service_name); ?>')" class="btn-admin btn-admin-primary" style="padding: 6px 12px; font-size: 12px;">
                                            <i class="fas fa-upload"></i> Fulfill
                                        </button>
                                    <?php else: ?>
                                        <button class="btn-admin btn-admin-outline" style="padding: 6px 12px; font-size: 12px; opacity: 0.5;" disabled>
                                            <i class="fas fa-check"></i> Done
                                        </button>
                                    <?php endif; ?>
                                    <button onclick='viewRequestDetails(<?php echo wp_json_encode($form_data); ?>)' class="btn-admin btn-admin-outline" style="padding: 6px 12px; font-size: 12px;">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: rgba(255,255,255,0.5);">
                        <i class="fas fa-id-card" style="font-size: 48px; margin-bottom: 15px;"></i>
                        <p>No NIN requests yet</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div><!-- End NIN Requests Section -->
            
        </main>
    </div>
    
    <!-- Fulfill NIN Request Modal -->
    <div class="admin-modal" id="fulfillNINModal">
        <div class="admin-modal-content" style="max-width: 600px;">
            <div class="admin-modal-header">
                <h2><i class="fas fa-upload"></i> Fulfill NIN Request</h2>
                <button class="admin-modal-close" onclick="closeModal('fulfillNINModal')">&times;</button>
            </div>
            
            <div id="fulfill-request-info" style="background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 10px; padding: 15px; margin-bottom: 20px;">
                <p style="margin: 0;"><strong>User:</strong> <span id="fulfill-user-name"></span></p>
                <p style="margin: 5px 0;"><strong>Email:</strong> <span id="fulfill-user-email"></span></p>
                <p style="margin: 5px 0;"><strong>NIN:</strong> <span id="fulfill-nin"></span></p>
                <p style="margin: 0;"><strong>Service:</strong> <span id="fulfill-service"></span></p>
            </div>
            
            <form id="fulfill-nin-form" method="POST" enctype="multipart/form-data" onsubmit="return submitFulfillment(event)">
                <input type="hidden" name="request_id" id="fulfill-request-id">
                <?php wp_nonce_field('zonatech_fulfill_nin', 'fulfill_nonce'); ?>
                
                <div class="admin-form-group">
                    <label><i class="fas fa-file"></i> Upload Document (PDF/Image)</label>
                    <input type="file" name="nin_document" id="nin-document-file" accept=".pdf,.jpg,.jpeg,.png" style="padding: 12px;">
                    <small style="color: rgba(255,255,255,0.5);">Upload the NIN slip or document to send to the user</small>
                </div>
                
                <div class="admin-form-group">
                    <label><i class="fas fa-sticky-note"></i> Admin Notes (Optional)</label>
                    <textarea name="admin_notes" rows="2" placeholder="Any notes about this request"></textarea>
                </div>
                
                <div class="admin-form-group">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="send_email" value="1" checked style="width: 18px; height: 18px; accent-color: #8b5cf6;">
                        <span>Send email notification to user with document</span>
                    </label>
                </div>
                
                <div class="admin-form-group">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="send_whatsapp" value="1" style="width: 18px; height: 18px; accent-color: #22c55e;">
                        <span>Copy WhatsApp message (you'll send manually)</span>
                    </label>
                </div>
                
                <button type="submit" class="admin-form-submit" style="background: linear-gradient(135deg, #22c55e, #16a34a);">
                    <i class="fas fa-paper-plane"></i> Fulfill & Send to User
                </button>
            </form>
        </div>
    </div>
    
    <!-- View Request Details Modal -->
    <div class="admin-modal" id="viewDetailsModal">
        <div class="admin-modal-content" style="max-width: 500px;">
            <div class="admin-modal-header">
                <h2><i class="fas fa-info-circle"></i> Request Details</h2>
                <button class="admin-modal-close" onclick="closeModal('viewDetailsModal')">&times;</button>
            </div>
            <div id="request-details-content" style="padding: 10px;"></div>
        </div>
    </div>
    
    <!-- Add Question Modal -->
    <div class="admin-modal" id="addQuestionModal">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h2><i class="fas fa-plus-circle"></i> Add Questions</h2>
                <button class="admin-modal-close" onclick="closeModal('addQuestionModal')">&times;</button>
            </div>
            
            <div class="admin-tabs">
                <button class="admin-tab active" onclick="switchTab('singleQuestion', this)">Single Question</button>
                <button class="admin-tab" onclick="switchTab('bulkUpload', this)">Bulk Upload (CSV)</button>
                <button class="admin-tab" onclick="switchTab('docUpload', this)">Document Upload</button>
            </div>
            
            <!-- Single Question Form -->
            <div class="tab-content active" id="singleQuestion">
                <form method="POST" action="">
                    <?php wp_nonce_field('zonatech_add_question', 'question_nonce'); ?>
                    
                    <div class="admin-form-row-3">
                        <div class="admin-form-group">
                            <label>Exam Type *</label>
                            <select name="exam_type" required>
                                <option value="">Select Exam</option>
                                <option value="jamb">JAMB</option>
                                <option value="waec">WAEC</option>
                                <option value="neco">NECO</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label>Subject *</label>
                            <select name="subject" id="modalSubject" required>
                                <option value="">Select Subject</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label>Year *</label>
                            <select name="year" required>
                                <option value="">Select Year</option>
                                <?php for ($y = date('Y'); $y >= 2010; $y--): ?>
                                <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="admin-form-group">
                        <label>Question Text *</label>
                        <textarea name="question_text" placeholder="Enter the question..." required></textarea>
                    </div>
                    
                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Option A *</label>
                            <input type="text" name="option_a" placeholder="First option" required>
                        </div>
                        <div class="admin-form-group">
                            <label>Option B *</label>
                            <input type="text" name="option_b" placeholder="Second option" required>
                        </div>
                    </div>
                    
                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Option C *</label>
                            <input type="text" name="option_c" placeholder="Third option" required>
                        </div>
                        <div class="admin-form-group">
                            <label>Option D *</label>
                            <input type="text" name="option_d" placeholder="Fourth option" required>
                        </div>
                    </div>
                    
                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Correct Answer *</label>
                            <select name="correct_answer" required>
                                <option value="">Select Answer</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label>Explanation (Optional)</label>
                            <input type="text" name="explanation" placeholder="Why this answer is correct">
                        </div>
                    </div>
                    
                    <button type="submit" name="add_single_question" class="admin-form-submit">
                        <i class="fas fa-plus"></i> Add Question
                    </button>
                </form>
            </div>
            
            <!-- Bulk Upload Form -->
            <div class="tab-content" id="bulkUpload">
                <a href="#" onclick="downloadCSVTemplate(); return false;" class="download-template">
                    <i class="fas fa-download"></i> Download CSV Template
                </a>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <?php wp_nonce_field('zonatech_bulk_upload', 'bulk_nonce'); ?>
                    
                    <div class="file-upload-area" onclick="document.getElementById('csvFile').click();">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Click to upload CSV file</p>
                        <small>Format: exam_type, subject, year, question_text, option_a, option_b, option_c, option_d, correct_answer, explanation</small>
                        <input type="file" name="csv_file" id="csvFile" accept=".csv" onchange="handleFileSelect(this)">
                    </div>
                    
                    <p id="selectedFile" style="text-align: center; color: #8b5cf6; margin-bottom: 15px;"></p>
                    
                    <button type="submit" name="bulk_upload_questions" class="admin-form-submit">
                        <i class="fas fa-upload"></i> Upload Questions
                    </button>
                </form>
                
                <div style="margin-top: 20px; padding: 15px; background: rgba(59, 130, 246, 0.1); border-radius: 10px;">
                    <h4 style="margin-bottom: 10px; color: #3b82f6;"><i class="fas fa-info-circle"></i> CSV Format Guide</h4>
                    <p style="font-size: 13px; color: rgba(255,255,255,0.7); line-height: 1.6;">
                        Each row should contain: exam_type (jamb/waec/neco), subject, year, question_text, option_a, option_b, option_c, option_d, correct_answer (A/B/C/D), explanation (optional)
                    </p>
                </div>
            </div>
            
            <!-- Document Upload Tab -->
            <div class="tab-content" id="docUpload">
                <div style="margin-bottom: 20px; padding: 15px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 10px;">
                    <h4 style="margin-bottom: 10px; color: #10b981;"><i class="fas fa-magic"></i> Smart Document Parser</h4>
                    <p style="font-size: 13px; color: rgba(255,255,255,0.7); line-height: 1.6;">
                        Upload a DOC, DOCX, PDF, or TXT file with questions. The system will intelligently extract questions and options.
                    </p>
                </div>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <?php wp_nonce_field('zonatech_doc_upload', 'doc_nonce'); ?>
                    
                    <div class="admin-form-row-3">
                        <div class="admin-form-group">
                            <label><i class="fas fa-graduation-cap"></i> Exam Type *</label>
                            <select name="doc_exam_type" id="docExamType" required>
                                <option value="">Select Exam</option>
                                <option value="jamb">JAMB</option>
                                <option value="waec">WAEC</option>
                                <option value="neco">NECO</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label><i class="fas fa-book"></i> Subject *</label>
                            <select name="doc_subject" id="docSubject" required>
                                <option value="">Select Subject</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label><i class="fas fa-calendar"></i> Year *</label>
                            <select name="doc_year" required>
                                <option value="">Select Year</option>
                                <?php for ($y = date('Y'); $y >= 2010; $y--): ?>
                                <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="file-upload-area" onclick="document.getElementById('docFile').click();" style="margin-top: 15px;">
                        <i class="fas fa-file-alt"></i>
                        <p>Click to upload DOC, DOCX, PDF, or TXT file</p>
                        <small>Questions will be automatically extracted from your document</small>
                        <input type="file" name="doc_file" id="docFile" accept=".doc,.docx,.pdf,.txt" onchange="handleDocSelect(this)">
                    </div>
                    
                    <p id="selectedDoc" style="text-align: center; color: #10b981; margin-bottom: 15px;"></p>
                    
                    <button type="submit" name="doc_upload_questions" class="admin-form-submit" style="background: linear-gradient(135deg, #10b981, #059669);">
                        <i class="fas fa-magic"></i> Parse & Upload Questions
                    </button>
                </form>
                
                <div style="margin-top: 25px; padding: 20px; background: rgba(139, 92, 246, 0.1); border-radius: 12px;">
                    <h4 style="margin-bottom: 15px; color: #a78bfa;"><i class="fas fa-lightbulb"></i> Document Format Tips</h4>
                    <div style="font-size: 13px; color: rgba(255,255,255,0.8); line-height: 1.8;">
                        <p style="margin-bottom: 10px;">For best results, format your document like this:</p>
                        <div style="background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px;">
                            <p style="color: #f59e0b;">1. What is the capital of Nigeria?</p>
                            <p>A. Abuja</p>
                            <p>B. Lagos</p>
                            <p>C. Kano</p>
                            <p>D. Ibadan</p>
                            <p style="color: #10b981;">Answer: A</p>
                            <br>
                            <p style="color: #f59e0b;">2. Which river is the longest in Africa?</p>
                            <p>A. Niger River</p>
                            <p>B. Nile River *</p>
                            <p>C. Congo River</p>
                            <p>D. Zambezi River</p>
                        </div>
                        <p style="margin-top: 15px; color: rgba(255,255,255,0.6);">
                            <strong>Tips:</strong> Mark correct answers with *, (correct), or "Answer: X" after options.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Manage Cards Modal -->
    <div class="admin-modal" id="manageCardsModal">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h2><i class="fas fa-ticket-alt"></i> Generate Scratch Cards</h2>
                <button class="admin-modal-close" onclick="closeModal('manageCardsModal')">&times;</button>
            </div>
            
            <form method="POST" action="">
                <?php wp_nonce_field('zonatech_generate_cards', 'cards_nonce'); ?>
                
                <div class="admin-form-row">
                    <div class="admin-form-group">
                        <label>Card Type *</label>
                        <select name="card_type" required>
                            <option value="">Select Type</option>
                            <option value="waec">WAEC Result Checker</option>
                            <option value="neco">NECO Result Checker</option>
                            <option value="jamb">JAMB Profile Code</option>
                        </select>
                    </div>
                    <div class="admin-form-group">
                        <label>Quantity (1-100) *</label>
                        <input type="number" name="quantity" min="1" max="100" placeholder="Number of cards" required>
                    </div>
                </div>
                
                <button type="submit" name="generate_cards" class="admin-form-submit">
                    <i class="fas fa-magic"></i> Generate Cards
                </button>
            </form>
            
            <div style="margin-top: 25px;">
                <h3 style="font-size: 16px; margin-bottom: 15px; color: rgba(255,255,255,0.8);"><i class="fas fa-list"></i> Current Stock</h3>
                <?php if (!empty($available_cards)): ?>
                <div class="three-columns">
                    <?php foreach ($available_cards as $card): ?>
                    <div class="card-info">
                        <h4><?php echo strtoupper(esc_html($card->card_type)); ?></h4>
                        <div class="value"><?php echo number_format($card->count); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p style="text-align: center; color: rgba(255,255,255,0.5);">No scratch cards in stock</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Settings Modal -->
    <div class="admin-modal" id="settingsModal">
        <div class="admin-modal-content" style="max-width: 700px;">
            <div class="admin-modal-header">
                <h2><i class="fas fa-cog"></i> Settings</h2>
                <button class="admin-modal-close" onclick="closeModal('settingsModal')">&times;</button>
            </div>
            
            <!-- Paystack API Keys Section -->
            <div style="margin-bottom: 30px; padding: 20px; background: rgba(139, 92, 246, 0.05); border: 1px solid rgba(139, 92, 246, 0.2); border-radius: 12px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px;">
                    <h3 style="font-size: 18px; display: flex; align-items: center; gap: 10px; margin: 0;">
                        <i class="fas fa-credit-card" style="color: #8b5cf6;"></i> Paystack API Keys
                    </h3>
                    <?php if ($is_test_mode): ?>
                    <span style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                        <i class="fas fa-flask"></i> TEST MODE
                    </span>
                    <?php elseif (!empty($paystack_public_key)): ?>
                    <span style="background: rgba(16, 185, 129, 0.2); color: #10b981; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                        <i class="fas fa-check-circle"></i> LIVE MODE
                    </span>
                    <?php else: ?>
                    <span style="background: rgba(239, 68, 68, 0.2); color: #ef4444; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                        <i class="fas fa-exclamation-circle"></i> NOT CONFIGURED
                    </span>
                    <?php endif; ?>
                </div>
                
                <div style="padding: 12px 15px; background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 8px; margin-bottom: 15px;">
                    <p style="font-size: 13px; color: rgba(255,255,255,0.8); margin: 0;">
                        <i class="fas fa-info-circle" style="color: #3b82f6;"></i> 
                        Get your API keys from <a href="https://dashboard.paystack.com/#/settings/developer" target="_blank" style="color: #8b5cf6; font-weight: 600;">Paystack Dashboard</a>
                    </p>
                </div>
                
                <!-- Key Type Instructions -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                    <div style="padding: 10px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 8px;">
                        <p style="font-size: 12px; color: #f59e0b; margin: 0; font-weight: 600;"><i class="fas fa-flask"></i> Test Keys</p>
                        <p style="font-size: 11px; color: rgba(255,255,255,0.6); margin: 5px 0 0 0;">pk_test_xxx / sk_test_xxx<br>For testing payments</p>
                    </div>
                    <div style="padding: 10px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px;">
                        <p style="font-size: 12px; color: #10b981; margin: 0; font-weight: 600;"><i class="fas fa-check-circle"></i> Live Keys</p>
                        <p style="font-size: 11px; color: rgba(255,255,255,0.6); margin: 5px 0 0 0;">pk_live_xxx / sk_live_xxx<br>For real payments</p>
                    </div>
                </div>
                
                <form method="POST" action="">
                    <?php wp_nonce_field('zonatech_save_paystack', 'paystack_nonce'); ?>
                    
                    <div class="admin-form-group">
                        <label><i class="fas fa-key"></i> Public Key <span style="color: <?php echo $is_test_mode ? '#f59e0b' : (!empty($paystack_public_key) ? '#10b981' : '#ef4444'); ?>;">(<?php echo $is_test_mode ? 'Test' : (!empty($paystack_public_key) ? 'Live' : 'Not Set'); ?>)</span></label>
                        <input type="text" name="paystack_public_key" value="<?php echo esc_attr($paystack_public_key); ?>" placeholder="pk_test_xxxxx or pk_live_xxxxx" style="font-family: monospace;">
                    </div>
                    
                    <div class="admin-form-group">
                        <label><i class="fas fa-lock"></i> Secret Key <?php echo !empty($paystack_secret_key) ? '<span style="color: #10b981;"><i class="fas fa-check-circle"></i> Set</span>' : '<span style="color: #ef4444;">Not Set</span>'; ?></label>
                        <input type="password" name="paystack_secret_key" value="<?php echo !empty($paystack_secret_key) ? '••••••••••••••••' : ''; ?>" placeholder="sk_test_xxxxx or sk_live_xxxxx" style="font-family: monospace;" <?php echo !empty($paystack_secret_key) ? 'onfocus="if(this.value===\'••••••••••••••••\')this.value=\'\';"' : ''; ?>>
                    </div>
                    
                    <button type="submit" name="save_paystack_settings" class="admin-form-submit" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                        <i class="fas fa-save"></i> Save Paystack Keys
                    </button>
                </form>
                
                <!-- Webhook URL -->
                <div style="margin-top: 15px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                    <p style="font-size: 12px; color: rgba(255,255,255,0.6); margin: 0 0 8px 0;"><i class="fas fa-link"></i> Webhook URL (add to Paystack):</p>
                    <code style="display: block; font-size: 10px; word-break: break-all; color: #a78bfa; background: rgba(0,0,0,0.3); padding: 8px; border-radius: 6px;">
                        <?php echo home_url('/wp-admin/admin-ajax.php?action=zonatech_paystack_webhook'); ?>
                    </code>
                </div>
            </div>
            
            <!-- OtaPay API Section -->
            <div style="margin-bottom: 30px; padding: 20px; background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 12px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px;">
                    <h3 style="font-size: 18px; display: flex; align-items: center; gap: 10px; margin: 0;">
                        <i class="fas fa-ticket-alt" style="color: #10b981;"></i> OtaPay.ng API (Scratch Cards)
                    </h3>
                    <?php if ($otapay_enabled === '1' && !empty($otapay_api_key)): ?>
                    <span style="background: rgba(16, 185, 129, 0.2); color: #10b981; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                        <i class="fas fa-check-circle"></i> ENABLED
                    </span>
                    <?php else: ?>
                    <span style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600;">
                        <i class="fas fa-pause-circle"></i> DISABLED
                    </span>
                    <?php endif; ?>
                </div>
                
                <div style="padding: 12px 15px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; margin-bottom: 15px;">
                    <p style="font-size: 13px; color: rgba(255,255,255,0.8); margin: 0;">
                        <i class="fas fa-info-circle" style="color: #10b981;"></i> 
                        OtaPay enables automatic purchase of <strong>WAEC</strong> and <strong>NECO</strong> scratch cards. Get your API key from <a href="https://app.otapay.ng" target="_blank" style="color: #10b981; font-weight: 600;">OtaPay.ng</a>
                    </p>
                </div>
                
                <form method="POST" action="">
                    <?php wp_nonce_field('zonatech_save_otapay', 'otapay_nonce'); ?>
                    
                    <div class="admin-form-group">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" name="otapay_enabled" value="1" <?php checked($otapay_enabled, '1'); ?> style="width: 18px; height: 18px; accent-color: #10b981;">
                            <span>Enable OtaPay Auto-Purchase</span>
                        </label>
                        <small style="color: rgba(255,255,255,0.5); font-size: 11px; display: block; margin-top: 5px;">When enabled, WAEC/NECO cards will be purchased automatically from OtaPay after payment</small>
                    </div>
                    
                    <div class="admin-form-group">
                        <label><i class="fas fa-key"></i> OtaPay API Key <?php echo !empty($otapay_api_key) ? '<span style="color: #10b981;"><i class="fas fa-check-circle"></i> Set</span>' : '<span style="color: #ef4444;">Not Set</span>'; ?></label>
                        <input type="password" name="otapay_api_key" value="<?php echo !empty($otapay_api_key) ? '••••••••••••••••' : ''; ?>" placeholder="Your OtaPay API key" style="font-family: monospace;" <?php echo !empty($otapay_api_key) ? 'onfocus="if(this.value===\'••••••••••••••••\')this.value=\'\';"' : ''; ?>>
                        <small style="color: rgba(255,255,255,0.5); font-size: 11px; display: block; margin-top: 5px;">Your secret API key from OtaPay dashboard</small>
                    </div>
                    
                    <button type="submit" name="save_otapay_settings" class="admin-form-submit" style="background: linear-gradient(135deg, #10b981, #059669);">
                        <i class="fas fa-save"></i> Save OtaPay Settings
                    </button>
                </form>
                
                <!-- OtaPay Provider Info -->
                <div style="margin-top: 15px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                    <p style="font-size: 12px; color: rgba(255,255,255,0.6); margin: 0 0 8px 0;"><i class="fas fa-tags"></i> Supported Providers & Prices:</p>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <span style="background: rgba(34, 197, 94, 0.2); color: #22c55e; padding: 6px 12px; border-radius: 6px; font-size: 12px;"><strong>WAEC</strong> - ₦3,850</span>
                        <span style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; padding: 6px 12px; border-radius: 6px; font-size: 12px;"><strong>NECO</strong> - ₦2,550</span>
                    </div>
                </div>
            </div>
            
            <!-- Pricing Info -->
            <div style="padding: 20px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px;">
                <h3 style="font-size: 16px; margin-bottom: 15px;"><i class="fas fa-sliders-h"></i> Pricing Info</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px;">
                    <div class="card-info">
                        <h4>Subject</h4>
                        <div class="value">₦5,000</div>
                    </div>
                    <div class="card-info" style="border-left: 3px solid #22c55e;">
                        <h4>WAEC Card</h4>
                        <div class="value" style="color: #22c55e;">₦3,850</div>
                    </div>
                    <div class="card-info" style="border-left: 3px solid #f59e0b;">
                        <h4>NECO Card</h4>
                        <div class="value" style="color: #f59e0b;">₦2,550</div>
                    </div>
                    <div class="card-info">
                        <h4>NIN Slip</h4>
                        <div class="value">₦1-2K</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('open');
        }
        
        // Section switching for admin navigation
        function switchSection(sectionId, link) {
            // Hide all section containers
            document.querySelectorAll('.admin-section-container').forEach(section => {
                section.style.display = 'none';
            });
            
            // Show the selected section
            const targetSection = document.getElementById(sectionId + '-section');
            if (targetSection) {
                targetSection.style.display = 'block';
            }
            
            // Update active state in navigation
            document.querySelectorAll('.admin-nav a').forEach(navLink => {
                navLink.classList.remove('active');
            });
            link.classList.add('active');
            
            // Close mobile sidebar
            if (window.innerWidth <= 768) {
                document.getElementById('adminSidebar').classList.remove('open');
            }
        }
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('adminSidebar');
            const toggle = document.querySelector('.mobile-menu-toggle');
            if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !toggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
        
        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
            document.body.style.overflow = '';
        }
        
        // Close modal on backdrop click
        document.querySelectorAll('.admin-modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
        
        // Tab switching
        function switchTab(tabId, button) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.admin-tab').forEach(btn => btn.classList.remove('active'));
            
            // Show selected tab
            document.getElementById(tabId).classList.add('active');
            button.classList.add('active');
        }
        
        // File upload handling
        function handleFileSelect(input) {
            const fileName = input.files[0]?.name;
            if (fileName) {
                document.getElementById('selectedFile').textContent = 'Selected: ' + fileName;
            }
        }
        
        // Document file upload handling
        function handleDocSelect(input) {
            const fileName = input.files[0]?.name;
            if (fileName) {
                document.getElementById('selectedDoc').textContent = 'Selected: ' + fileName;
            }
        }
        
        // Download CSV template
        function downloadCSVTemplate() {
            const headers = 'exam_type,subject,year,question_text,option_a,option_b,option_c,option_d,correct_answer,explanation\n';
            const example = 'jamb,Mathematics,2023,"What is 2 + 2?",3,4,5,6,B,"2 + 2 equals 4"';
            const blob = new Blob([headers + example], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'zonatech_questions_template.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }
        
        // Subject dropdown population based on exam type
        const subjects = {
            jamb: ['Use of English', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Agricultural Science', 'Economics', 'Commerce', 'Accounting', 'Government', 'Geography', 'Literature in English', 'Christian Religious Studies', 'Islamic Religious Studies', 'History', 'Civic Education', 'Home Economics', 'Food & Nutrition', 'Fine Arts', 'Music', 'French', 'Arabic', 'Hausa', 'Igbo', 'Yoruba', 'Physical Education'],
            waec: ['English Language', 'Mathematics', 'Civic Education', 'Physics', 'Chemistry', 'Biology', 'Agricultural Science', 'Further Mathematics', 'Health Education', 'Economics', 'Commerce', 'Financial Accounting', 'Literature in English', 'Government', 'History', 'Christian Religious Studies', 'Islamic Religious Studies', 'Geography', 'Fine Arts', 'Music', 'French', 'Arabic', 'Hausa', 'Igbo', 'Yoruba', 'Data Processing', 'Computer Studies', 'Animal Husbandry', 'Technical Drawing'],
            neco: ['English Language', 'Mathematics', 'Civic Education', 'Physics', 'Chemistry', 'Biology', 'Agricultural Science', 'Further Mathematics', 'Health Science', 'Economics', 'Commerce', 'Financial Accounting', 'Literature in English', 'Government', 'History', 'Christian Religious Studies', 'Islamic Religious Studies', 'Geography', 'Fine Arts', 'Music', 'French', 'Arabic', 'Hausa', 'Igbo', 'Yoruba', 'Computer Studies', 'Data Processing', 'Marketing', 'Home Economics', 'Animal Husbandry', 'Technical Drawing']
        };
        
        // Update subjects for single question form
        document.querySelector('select[name="exam_type"]')?.addEventListener('change', function() {
            const subjectSelect = document.getElementById('modalSubject');
            subjectSelect.innerHTML = '<option value="">Select Subject</option>';
            
            const examSubjects = subjects[this.value] || [];
            examSubjects.forEach(subject => {
                const option = document.createElement('option');
                option.value = subject;
                option.textContent = subject;
                subjectSelect.appendChild(option);
            });
        });
        
        // Update subjects for document upload form
        document.getElementById('docExamType')?.addEventListener('change', function() {
            const subjectSelect = document.getElementById('docSubject');
            subjectSelect.innerHTML = '<option value="">Select Subject</option>';
            
            const examSubjects = subjects[this.value] || [];
            examSubjects.forEach(subject => {
                const option = document.createElement('option');
                option.value = subject;
                option.textContent = subject;
                subjectSelect.appendChild(option);
            });
        });
        
        // NIN Fulfillment Functions
        function openFulfillModal(requestId, userName, userEmail, nin, service) {
            document.getElementById('fulfill-request-id').value = requestId;
            document.getElementById('fulfill-user-name').textContent = userName;
            document.getElementById('fulfill-user-email').textContent = userEmail;
            document.getElementById('fulfill-nin').textContent = nin;
            document.getElementById('fulfill-service').textContent = service;
            openModal('fulfillNINModal');
        }
        
        function viewRequestDetails(formData) {
            let html = '<div style="background: rgba(0,0,0,0.2); border-radius: 10px; padding: 15px;">';
            for (let key in formData) {
                if (formData.hasOwnProperty(key) && formData[key]) {
                    let label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    html += '<p style="margin: 8px 0;"><strong style="color: #a78bfa;">' + label + ':</strong> ' + formData[key] + '</p>';
                }
            }
            html += '</div>';
            document.getElementById('request-details-content').innerHTML = html;
            openModal('viewDetailsModal');
        }
        
        function submitFulfillment(event) {
            event.preventDefault();
            const form = document.getElementById('fulfill-nin-form');
            const formData = new FormData(form);
            formData.append('action', 'zonatech_fulfill_nin_request');
            
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            submitBtn.disabled = true;
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Request fulfilled successfully! Email sent to user.');
                    closeModal('fulfillNINModal');
                    location.reload();
                } else {
                    alert(data.data?.message || 'Failed to fulfill request');
                }
            })
            .catch(error => {
                alert('Error: ' + error.message);
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
            
            return false;
        }
    </script>
</body>
</html>